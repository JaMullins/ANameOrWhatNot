import math
import random
import pynput
import pyautogui
from tkinter import messagebox as mb
import tkinter as tk
import webbrowser

boss = False

def callback(url):
    webbrowser.open_new(url)
class AntiClick:
    def __init__(self):
        self.last_mouse_position = (0, 0)
        self.if_click = False
        self.keyboard_listener = pynput.keyboard.Listener(on_press=self.on_press,on_release=self.on_release)
        self.mouse_listener = pynput.mouse.Listener(on_move=self.on_move,on_click=self.on_click)

        self.keyboard_listener.start()
        self.mouse_listener.start()
        self.keyboard_listener.join()
        self.mouse_listener.join()



    def on_click(self, x, y, button, pressed):
        if boss:
            decide = random.randint(0, 6)
            if decide == 1 and pressed:
                pass
            elif decide == 2 and pressed:
                fileList = ["ad_1.png","ad_2.png","ad_3.png","ad_4.png","ad_5.png","ad_6.png"]
                FILE = fileList[random.randint(0,len(fileList)-1)]
                win = tk.Toplevel()
                image = tk.PhotoImage(file=FILE)
                btn = tk.Button(win, image=image, cursor="hand2")
                win.overrideredirect(True)
                win.attributes("-topmost", True)
                win.attributes("-disabled", True)
                btn.pack()
                btn.bind("<Button-1>", lambda e: callback("http://youtube.com"))
                x,y = self.get_last_mouse_position() if self.get_last_mouse_position() else (None,None)
                x -= math.floor(image.width()/2)
                y -= math.floor(image.height()/2)
                win.geometry('+{}+{}'.format(x,y))
                win.mainloop()
            elif decide >= 3 and pressed:
                ran_num_x = random.randint(-100, 100)
                ran_num_y = random.randint(-100, 100)
                pyautogui.moveTo(x + ran_num_x, y + ran_num_y, duration=0.1)
        if pressed:
            self.if_click = True
            ran_num_x = random.randint(-100, 100)
            ran_num_y = random.randint(-100, 100)
            pyautogui.moveTo(x + ran_num_x, y + ran_num_y, duration=0.1)
        else:
            self.if_click = False

    def on_move(self, x, y):
        self.last_mouse_position = (x, y)

    def on_press(self, key):
        if key == pynput.keyboard.KeyCode.from_char('a'):
            pyautogui.press('backspace')
        elif key == pynput.keyboard.KeyCode.from_char('e'):
            pyautogui.press('backspace')
        elif key == pynput.keyboard.KeyCode.from_char('i'):
            pyautogui.press('backspace')
        elif key == pynput.keyboard.KeyCode.from_char('o'):
            pyautogui.press('backspace')
        elif key == pynput.keyboard.KeyCode.from_char('u'):
            pyautogui.press('backspace')
        elif key == pynput.keyboard.KeyCode.from_char('y'):
            pyautogui.press('backspace')

    def on_release(self, key):
        global boss
        if key == pynput.keyboard.Key.insert:
            if boss:
                mb.showwarning('Nope.', 'Fool me once...[DEL SYS32]')
            else:
                self.mouse_listener.stop()
                self.keyboard_listener.stop()
                mb.showerror('','HEY')
                mb.showwarning('',"YOU SHOULDN'T KNOW THAT")
                boss = True
                return False

    def get_last_mouse_position(self):
        return self.last_mouse_position

    def not_click(self):
        return self.if_click