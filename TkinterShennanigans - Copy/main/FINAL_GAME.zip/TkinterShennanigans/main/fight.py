import tkinter as tk
import pynput as pyn
import pygame as pg
import pyautogui as pya
import BetterShennanigans as bs

def bossFight(): #for when [REDACTED] gets angry and start to mess with your computer
    bossCode = bs.AntiClick()
    bossCode.__init__()
    print('first init')
    while bossCode.mouse_listener.is_alive():
        print('alive')
    bossCode.__init__()
    print('second init')
bossFight()